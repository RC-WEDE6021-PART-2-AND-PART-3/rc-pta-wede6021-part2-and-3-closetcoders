<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
include "DBConn.php";

$conn->query("SET FOREIGN_KEY_CHECKS = 0");
$conn->query("DROP TABLE IF EXISTS tblReviews");
$conn->query("DROP TABLE IF EXISTS tblCart");
$conn->query("DROP TABLE IF EXISTS tblOrders");
$conn->query("DROP TABLE IF EXISTS tblProducts");
$conn->query("DROP TABLE IF EXISTS tblUser");
$conn->query("SET FOREIGN_KEY_CHECKS = 1");

$conn->query("
CREATE TABLE tblUser (
    user_id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100),
    email VARCHAR(100) UNIQUE,
    password VARCHAR(255),
    role ENUM('buyer','seller','admin') DEFAULT 'buyer',
    status ENUM('pending','approved') DEFAULT 'approved',
    join_date DATETIME DEFAULT CURRENT_TIMESTAMP,
    wallet_balance DECIMAL(10,2) DEFAULT 0
)");

$conn->query("
CREATE TABLE tblProducts (
    product_id INT AUTO_INCREMENT PRIMARY KEY,
    seller_id INT,
    title VARCHAR(100),
    description TEXT,
    price DECIMAL(10,2),
    category VARCHAR(50),
    size VARCHAR(20),
    condition_type ENUM('Like New','Good','Fair') DEFAULT 'Good',
    status ENUM('active','sold') DEFAULT 'active',
    date_listed DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (seller_id) REFERENCES tblUser(user_id)
)");

$conn->query("
CREATE TABLE tblCart (
    cart_id INT AUTO_INCREMENT PRIMARY KEY,
    buyer_id INT,
    product_id INT,
    added_on DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (buyer_id) REFERENCES tblUser(user_id),
    FOREIGN KEY (product_id) REFERENCES tblProducts(product_id)
)");

$conn->query("
CREATE TABLE tblOrders (
    order_id INT AUTO_INCREMENT PRIMARY KEY,
    buyer_id INT,
    product_id INT,
    amount DECIMAL(10,2),
    status ENUM('paid','shipped','completed') DEFAULT 'paid',
    date_ordered DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (buyer_id) REFERENCES tblUser(user_id),
    FOREIGN KEY (product_id) REFERENCES tblProducts(product_id)
)");

$conn->query("
CREATE TABLE tblReviews (
    review_id INT AUTO_INCREMENT PRIMARY KEY,
    product_id INT,
    buyer_id INT,
    rating INT CHECK (rating BETWEEN 1 AND 5),
    comment TEXT,
    date_reviewed DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (product_id) REFERENCES tblProducts(product_id),
    FOREIGN KEY (buyer_id) REFERENCES tblUser(user_id)
)");

echo "Tables created.<br>";

// Default admin
$adminPass = password_hash("admin123", PASSWORD_DEFAULT);
$conn->query("INSERT INTO tblUser (name, email, password, role, status) 
              VALUES ('Admin', 'admin@pastimes.co.za', '$adminPass', 'admin', 'approved')");
echo "Admin created: admin@pastimes.co.za / admin123<br>";

// Sample seller
$sellerPass = password_hash("seller123", PASSWORD_DEFAULT);
$conn->query("INSERT INTO tblUser (name, email, password, role, status) 
              VALUES ('Sample Seller', 'seller@pastimes.co.za', '$sellerPass', 'seller', 'approved')");
$seller_id = $conn->insert_id;
echo "Seller created: seller@pastimes.co.za / seller123<br>";

// Sample buyer
$buyerPass = password_hash("buyer123", PASSWORD_DEFAULT);
$conn->query("INSERT INTO tblUser (name, email, password, role, status) 
              VALUES ('Sample Buyer', 'buyer@pastimes.co.za', '$buyerPass', 'buyer', 'approved')");
echo "Buyer created: buyer@pastimes.co.za / buyer123<br>";

// Sample products
$products = [
    ["Vintage Denim Jacket", "Classic 90s denim jacket in excellent condition.", 350.00, "Jackets", "M", "Like New"],
    ["Floral Summer Dress", "Light and breezy floral dress perfect for summer.", 180.00, "Dresses", "S", "Good"],
    ["Black Skinny Jeans", "Slim fit black jeans, barely worn.", 220.00, "Pants", "L", "Like New"],
    ["White Oversized Hoodie", "Cozy oversized hoodie in white.", 270.00, "Hoodies", "XL", "Good"],
    ["Leather Ankle Boots", "Brown leather ankle boots, light wear.", 450.00, "Shoes", "7", "Good"],
    ["Striped Crop Top", "Cute striped crop top for casual wear.", 120.00, "Tops", "XS", "Fair"],
];

foreach ($products as $p) {
    $title = $p[0]; $desc = $p[1]; $price = $p[2];
    $cat = $p[3]; $size = $p[4]; $cond = $p[5];
    $conn->query("INSERT INTO tblProducts (seller_id, title, description, price, category, size, condition_type)
                  VALUES ($seller_id, '$title', '$desc', $price, '$cat', '$size', '$cond')");
}
echo "Sample products added.<br>";

echo "<br><strong>Setup complete! <a href='login.php'>Go to Login</a></strong>";
?>