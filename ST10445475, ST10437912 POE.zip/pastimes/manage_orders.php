<?php
session_start();
include "DBConn.php";

if (!isset($_SESSION['admin_id']) && !isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$is_admin = isset($_SESSION['admin_id']);
$is_seller = isset($_SESSION['role']) && $_SESSION['role'] == 'seller';

if (isset($_POST['update_status'])) {
    $order_id = (int)$_POST['order_id'];
    $status = $_POST['status'];

    if ($is_admin) {
        $conn->query("UPDATE tblOrders SET status='$status' WHERE order_id=$order_id");
    } else {
        $seller_id = $_SESSION['user_id'];
        $conn->query("UPDATE tblOrders SET status='$status' WHERE order_id=$order_id AND seller_id=$seller_id");
    }

    header("Location: manage_orders.php?updated=1");
    exit();
}

if ($is_admin) {
    $orders = $conn->query("
        SELECT o.*, p.title, b.name AS buyer_name, s.name AS seller_name
        FROM tblOrders o
        JOIN tblProducts p ON o.product_id = p.product_id
        JOIN tblUser b ON o.buyer_id = b.user_id
        JOIN tblUser s ON o.seller_id = s.user_id
        ORDER BY o.date_ordered DESC
    ");
} else {
    $seller_id = $_SESSION['user_id'];
    $orders = $conn->query("
        SELECT o.*, p.title, b.name AS buyer_name
        FROM tblOrders o
        JOIN tblProducts p ON o.product_id = p.product_id
        JOIN tblUser b ON o.buyer_id = b.user_id
        WHERE o.seller_id=$seller_id
        ORDER BY o.date_ordered DESC
    ");
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Manage Orders - Pastimes</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

<div class="topbar">
    <h1>Manage Orders</h1>
    <div>
        <?php if ($is_admin): ?>
            <a href="admin_dashboard.php">Admin Dashboard</a>
        <?php else: ?>
            <a href="seller_dashboard.php">Seller Dashboard</a>
        <?php endif; ?>
        |
        <a href="logout.php">Logout</a>
    </div>
</div>

<div style="padding:20px;">
    <h2>Orders</h2>

    <?php if (isset($_GET['updated'])): ?>
        <p class="success-msg">Order status updated.</p>
    <?php endif; ?>

    <table>
        <tr>
            <th>Order ID</th>
            <th>Product</th>
            <th>Buyer</th>
            <?php if ($is_admin): ?><th>Seller</th><?php endif; ?>
            <th>Total</th>
            <th>Delivery</th>
            <th>Tracking</th>
            <th>Status</th>
            <th>Update</th>
        </tr>

        <?php while ($o = $orders->fetch_assoc()): ?>
        <tr>
            <form method="POST">
                <td><?= $o['order_id'] ?></td>
                <td><?= htmlspecialchars($o['title']) ?></td>
                <td><?= htmlspecialchars($o['buyer_name']) ?></td>

                <?php if ($is_admin): ?>
                    <td><?= htmlspecialchars($o['seller_name']) ?></td>
                <?php endif; ?>

                <td>R<?= number_format($o['total'], 2) ?></td>
                <td><?= htmlspecialchars($o['delivery_method']) ?></td>
                <td><?= htmlspecialchars($o['tracking_number']) ?></td>

                <td>
                    <select name="status">
                        <?php foreach (['pending','paid','shipped','completed','refunded'] as $st): ?>
                            <option value="<?= $st ?>" <?= $o['status'] == $st ? 'selected' : '' ?>>
                                <?= ucfirst($st) ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </td>

                <td>
                    <input type="hidden" name="order_id" value="<?= $o['order_id'] ?>">
                    <button type="submit" name="update_status">Update</button>
                </td>
            </form>
        </tr>
        <?php endwhile; ?>
    </table>
</div>

</body>
</html>