<?php
session_start();
include "DBConn.php";

if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'buyer') {
    header("Location: login.php");
    exit();
}

$buyer_id = $_SESSION['user_id'];

$orders = $conn->query("
    SELECT o.*, p.title, p.image_url
    FROM tblOrders o
    JOIN tblProducts p ON o.product_id = p.product_id
    WHERE o.buyer_id=$buyer_id
    ORDER BY o.date_ordered DESC
");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Track Orders - Pastimes</title>
    <link rel="stylesheet" href="style.css?v=3">
</head>
<body>

<div class="topbar">
    <h1>Pastimes</h1>
    <div>
        <a href="dashboard.php">Shop</a>
        <a href="cart.php">Cart</a>
        <a href="logout.php">Logout</a>
    </div>
</div>

<div class="login-container" style="max-width:900px">
    <h2>Track Your Orders</h2>

    <?php if (isset($_GET['success'])): ?>
        <p class="success-msg">Order placed successfully! Your tracking number has been generated.</p>
    <?php endif; ?>

    <?php if ($orders->num_rows == 0): ?>
        <p>You have no orders yet.</p>
    <?php else: ?>
        <?php while ($order = $orders->fetch_assoc()): ?>
            <div class="order-card">
                <h3><?= htmlspecialchars($order['title']) ?></h3>

                <p><strong>Tracking Number:</strong> <?= htmlspecialchars($order['tracking_number']) ?></p>
                <p><strong>Status:</strong> <?= htmlspecialchars($order['status']) ?></p>
                <p><strong>Delivery Method:</strong> <?= htmlspecialchars($order['delivery_method']) ?></p>
                <p><strong>Delivery Address:</strong> <?= htmlspecialchars($order['delivery_address']) ?></p>
                <p><strong>Payment Method:</strong> <?= htmlspecialchars($order['payment_method']) ?></p>
                <p><strong>Total Paid:</strong> R<?= number_format($order['total'], 2) ?></p>
                <p><strong>Date Ordered:</strong> <?= htmlspecialchars($order['date_ordered']) ?></p>

                <div class="tracking-progress">
                    <span class="active-step">Paid</span>
                    <span class="<?= ($order['status'] == 'shipped' || $order['status'] == 'completed') ? 'active-step' : '' ?>">Shipped</span>
                    <span class="<?= ($order['status'] == 'completed') ? 'active-step' : '' ?>">Completed</span>
                </div>
            </div>
        <?php endwhile; ?>
    <?php endif; ?>
</div>

</body>
</html>