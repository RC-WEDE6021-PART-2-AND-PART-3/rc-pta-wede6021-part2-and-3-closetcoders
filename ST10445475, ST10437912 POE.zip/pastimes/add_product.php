<?php 
session_start();
include "DBConn.php";

if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'seller') {
    header("Location: login.php");
    exit();
}

$error = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $seller_id   = $_SESSION['user_id'];
    $title       = trim($_POST['title']);
    $brand       = trim($_POST['brand']);
    $description = trim($_POST['description']);
    $price       = (float)$_POST['price'];
    $category    = trim($_POST['category']);
    $size        = trim($_POST['size']);
    $condition   = $_POST['condition_type'];
    $status      = "active";

    $image_url = "";

    if (!empty($_FILES['image']['name'])) {
        $folder = "uploads/";
        $file_name = time() . "_" . basename($_FILES['image']['name']);
        $target = $folder . $file_name;

        if (move_uploaded_file($_FILES['image']['tmp_name'], $target)) {
            $image_url = $target;
        } else {
            $error = "Image upload failed.";
        }
    }

    if ($error == "") {
        $stmt = $conn->prepare("INSERT INTO tblProducts 
        (seller_id, title, brand, description, price, category, size, condition_type, status, image_url, date_listed) 
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW())");

        $stmt->bind_param("isssdsssss", $seller_id, $title, $brand, $description, $price, $category, $size, $condition, $status, $image_url);

        if ($stmt->execute()) {
            header("Location: seller_dashboard.php?saved=1");
            exit();
        } else {
            $error = "Something went wrong: " . $stmt->error;
        }
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Add Item - Pastimes</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

<div class="topbar">
    <h1>Pastimes</h1>
    <div><a href="seller_dashboard.php">← Back</a> | <a href="logout.php">Logout</a></div>
</div>

<div class="login-container">
    <h2>Add New Item</h2>

    <?php if ($error): ?>
        <p class="error"><?= htmlspecialchars($error) ?></p>
    <?php endif; ?>

    <form method="POST" enctype="multipart/form-data">
        <label>Title</label>
        <input type="text" name="title" required>

        <br><br>

        <label>Brand</label>
        <input type="text" name="brand" required>

        <br><br>

        <label>Description</label>
        <textarea name="description" required></textarea>

        <br><br>

        <label>Price</label>
        <input type="number" name="price" step="0.01" required>

        <br><br>

        <label>Category</label>
        <select name="category" required>
            <option>Tops</option>
            <option>Dresses</option>
            <option>Pants</option>
            <option>Jackets</option>
            <option>Hoodies</option>
            <option>Shoes</option>
            <option>Bags</option>
            <option>Sportswear</option>
            <option>Suits</option>
            <option>Accessories</option>
            <option>Other</option>
        </select>

        <br><br>

        <label>Size</label>
        <select name="size" required>
            <option>XS</option>
            <option>S</option>
            <option>M</option>
            <option>L</option>
            <option>XL</option>
            <option>XXL</option>
            <option>One Size</option>
        </select>

        <br><br>

        <label>Condition</label>
        <select name="condition_type" required>
            <option>New</option>
            <option>Like New</option>
            <option>Good</option>
            <option>Fair</option>
        </select>

        <br><br>

        <label>Upload Image</label>
        <input type="file" name="image" accept="image/*" required>

        <br><br>

        <button type="submit">Add Item</button>
    </form>
</div>

</body>
</html>