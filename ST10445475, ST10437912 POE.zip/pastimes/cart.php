<?php
session_start();
include "DBConn.php";

if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'buyer') {
    header("Location: login.php");
    exit();
}

$buyer_id = $_SESSION['user_id'];

if (isset($_GET['remove'])) {
    $cart_id = (int)$_GET['remove'];
    $conn->query("DELETE FROM tblCart WHERE cart_id=$cart_id AND buyer_id=$buyer_id");
    header("Location: cart.php");
    exit();
}

if (isset($_POST['purchase'])) {
    $delivery_method = $_POST['delivery_method'];
    $delivery_address = $conn->real_escape_string($_POST['delivery_address']);
    $payment_method = $_POST['payment_method'];

    if ($delivery_method == "PUDO Locker") {
        $delivery_fee = 60;
    } elseif ($delivery_method == "PAXI") {
        $delivery_fee = 70;
    } else {
        $delivery_fee = 100;
    }

    $cart_items = $conn->query("
        SELECT c.cart_id, p.product_id, p.seller_id, p.price
        FROM tblCart c
        JOIN tblProducts p ON c.product_id = p.product_id
        WHERE c.buyer_id=$buyer_id AND p.status='active'
    ");

    while ($item = $cart_items->fetch_assoc()) {
        $total = $item['price'] + $delivery_fee;

        $conn->query("
            INSERT INTO tblOrders 
            (buyer_id, seller_id, product_id, amount, total, status, delivery_method, delivery_address, payment_method)
            VALUES 
            ($buyer_id, {$item['seller_id']}, {$item['product_id']}, {$item['price']}, $total, 'paid', '$delivery_method', '$delivery_address', '$payment_method')
        ");

        $order_id = $conn->insert_id;
        $tracking_number = "PTM" . str_pad($order_id, 5, "0", STR_PAD_LEFT);

        $conn->query("UPDATE tblOrders SET tracking_number='$tracking_number' WHERE order_id=$order_id");
        $conn->query("UPDATE tblProducts SET status='sold' WHERE product_id={$item['product_id']}");
        $conn->query("DELETE FROM tblCart WHERE cart_id={$item['cart_id']}");
    }

    header("Location: track_order.php?success=1");
    exit();
}

$cart_items = $conn->query("
    SELECT c.cart_id, p.*, u.name as seller_name
    FROM tblCart c
    JOIN tblProducts p ON c.product_id = p.product_id
    JOIN tblUser u ON p.seller_id = u.user_id
    WHERE c.buyer_id=$buyer_id AND p.status='active'
");

$total_result = $conn->query("
    SELECT SUM(p.price) as total 
    FROM tblCart c
    JOIN tblProducts p ON c.product_id = p.product_id
    WHERE c.buyer_id=$buyer_id AND p.status='active'
");

$total = $total_result->fetch_assoc()['total'] ?? 0;
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Cart - Pastimes</title>
    <link rel="stylesheet" href="style.css?v=3">
</head>
<body>

<div class="topbar">
    <h1>Pastimes</h1>
    <div>
        Welcome, <?= htmlspecialchars($_SESSION['name']) ?> |
        <a href="dashboard.php">← Back to Shop</a> |
        <a href="track_order.php">Track Orders</a> |
        <a href="logout.php">Logout</a>
        <a href="dashboard.php"><button>Continue Shopping</button></a>
    </div>
</div>

<div class="login-container" style="max-width:850px">
    <h2>Your Cart</h2>

    <?php if ($cart_items->num_rows == 0): ?>
        <p>Your cart is empty. <a href="dashboard.php">Browse items</a></p>
    <?php else: ?>

        <table>
            <tr>
                <th>Item</th>
                <th>Size</th>
                <th>Condition</th>
                <th>Seller</th>
                <th>Price</th>
                <th>Remove</th>
            </tr>

            <?php while ($item = $cart_items->fetch_assoc()): ?>
            <tr>
                <td><?= htmlspecialchars($item['title']) ?></td>
                <td><?= htmlspecialchars($item['size']) ?></td>
                <td><?= htmlspecialchars($item['condition_type']) ?></td>
                <td><?= htmlspecialchars($item['seller_name']) ?></td>
                <td>R<?= number_format($item['price'], 2) ?></td>
                <td><a href="?remove=<?= $item['cart_id'] ?>">Remove</a></td>
            </tr>
            <?php endwhile; ?>
        </table>

        <br>
        <p><strong>Cart Total: R<?= number_format($total, 2) ?></strong></p>

        <form method="POST" class="checkout-box">
            <h3>Checkout Details</h3>

            <label>Delivery Method</label>
            <select name="delivery_method" required>
                <option value="">Select delivery method</option>
                <option value="PUDO Locker">PUDO Locker - R60</option>
                <option value="PAXI">PAXI - R70</option>
                <option value="Courier">Courier Delivery - R100</option>
            </select>

            <br><br>

            <label>Delivery Address / PEP Code / Locker Details</label>
            <textarea name="delivery_address" required placeholder="Enter your address, PUDO locker location, or closest PEP store code"></textarea>

            <br><br>

            <label>Payment Method</label>
            <select name="payment_method" required>
                <option value="">Select payment method</option>
                <option value="Visa">Visa</option>
                <option value="Mastercard">Mastercard</option>
                <option value="American Express">American Express</option>
                <option value="PayFlex">PayFlex</option>
            </select>

            <br><br>

            <button type="submit" name="purchase">Confirm Purchase</button>
        </form>

    <?php endif; ?>
</div>

</body>
</html>