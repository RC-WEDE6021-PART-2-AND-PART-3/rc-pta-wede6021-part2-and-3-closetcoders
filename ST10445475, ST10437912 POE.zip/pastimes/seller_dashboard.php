<?php 
session_start();
include "DBConn.php";

if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'seller') {
    header("Location: login.php");
    exit();
}

$seller_id = $_SESSION['user_id'];

if (isset($_GET['delete'])) {
    $product_id = (int)$_GET['delete'];
    $conn->query("DELETE FROM tblCart WHERE product_id=$product_id");
    $conn->query("DELETE FROM tblReviews WHERE product_id=$product_id");
    $conn->query("DELETE FROM tblProducts WHERE product_id=$product_id AND seller_id=$seller_id");
    header("Location: seller_dashboard.php?deleted=1");
    exit();
}

$products = $conn->query("SELECT * FROM tblProducts WHERE seller_id=$seller_id ORDER BY date_listed DESC");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Seller Dashboard - Pastimes</title>
    <link rel="stylesheet" href="style.css?v=4">
</head>
<body>

<div class="topbar">
    <h1>Pastimes</h1>
    <div>
        Welcome, <?= htmlspecialchars($_SESSION['name']) ?> |
       <a href="add_product.php">+ Add Item</a> |
<a href="manage_orders.php">Orders</a> |
<a href="messages.php">Messages</a> |
<a href="seller_orders.php">Orders</a> |
<a href="logout.php">Logout</a>
    </div>
</div>

<div style="padding: 20px;">
    <h2>My Listings</h2>

    <?php if (isset($_GET['deleted'])): ?>
        <p class="success-msg">Item deleted.</p>
    <?php endif; ?>

    <?php if (isset($_GET['saved'])): ?>
        <p class="success-msg">Item saved successfully.</p>
    <?php endif; ?>

    <?php if ($products->num_rows == 0): ?>
        <p>You have no listings yet. <a href="add_product.php">Add your first item</a></p>
    <?php else: ?>

    <div class="product-grid">
        <?php while ($p = $products->fetch_assoc()): ?>

        <div class="product-card">

            <div class="product-image-container">
                <?php if (!empty($p['image_url'])): ?>
                    <img src="<?= htmlspecialchars($p['image_url']) ?>" 
                         alt="<?= htmlspecialchars($p['title']) ?>" 
                         class="product-image">
                <?php else: ?>
                    <div class="no-image">No Image</div>
                <?php endif; ?>
            </div>

            <div class="product-content">

                <div class="product-category">
                    <?= htmlspecialchars($p['category']) ?>
                </div>

                <span class="status-badge <?= $p['status'] == 'sold' ? 'badge-sold' : 'badge-active' ?>">
                    <?= ucfirst($p['status']) ?>
                </span>

                <h3><?= htmlspecialchars($p['title']) ?></h3>

                <?php if (isset($p['brand']) && !empty($p['brand'])): ?>
                    <p><strong>Brand:</strong> <?= htmlspecialchars($p['brand']) ?></p>
                <?php endif; ?>

                <p><?= htmlspecialchars($p['description']) ?></p>

                <p>
                    <strong>Size:</strong> <?= htmlspecialchars($p['size']) ?> |
                    <strong>Condition:</strong> <?= htmlspecialchars($p['condition_type']) ?>
                </p>

                <div class="product-footer">
                    <span class="price">R<?= number_format($p['price'], 2) ?></span>

                    <a href="edit_product.php?product_id=<?= $p['product_id'] ?>">
                        <button>Edit</button>
                    </a>

                    <a href="?delete=<?= $p['product_id'] ?>" 
                       onclick="return confirm('Delete this listing?')">
                        <button class="btn-danger">Delete</button>
                    </a>
                </div>

            </div>

        </div>

        <?php endwhile; ?>
    </div>

    <?php endif; ?>
</div>

</body>
</html>