<?php
session_start();
include "DBConn.php";

if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'seller') {
    header("Location: login.php");
    exit();
}

if (!isset($_GET['product_id'])) {
    header("Location: seller_dashboard.php");
    exit();
}

$product_id = (int)$_GET['product_id'];
$seller_id  = $_SESSION['user_id'];
$error = "";

$product = $conn->query("SELECT * FROM tblProducts WHERE product_id=$product_id AND seller_id=$seller_id")->fetch_assoc();

if (!$product) {
    die("Product not found.");
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $title       = trim($_POST['title']);
    $brand       = trim($_POST['brand']);
    $description = trim($_POST['description']);
    $price       = (float)$_POST['price'];
    $category    = trim($_POST['category']);
    $size        = trim($_POST['size']);
    $condition   = $_POST['condition_type'];
    $image_url   = trim($_POST['image_url']);
    $status      = $_POST['status'];

    $stmt = $conn->prepare("UPDATE tblProducts 
        SET title=?, brand=?, description=?, price=?, category=?, size=?, condition_type=?, image_url=?, status=? 
        WHERE product_id=? AND seller_id=?");

    $stmt->bind_param(
        "sssdsssssii",
        $title,
        $brand,
        $description,
        $price,
        $category,
        $size,
        $condition,
        $image_url,
        $status,
        $product_id,
        $seller_id
    );

    if ($stmt->execute()) {
        header("Location: seller_dashboard.php?saved=1");
        exit();
    } else {
        $error = "Something went wrong. " . $stmt->error;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Edit Item - Pastimes</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

<div class="topbar">
    <h1>Pastimes</h1>
    <div>
        <a href="seller_dashboard.php">← Back to My Listings</a> |
        <a href="logout.php">Logout</a>
    </div>
</div>

<div class="login-container">
    <h2>Edit Item</h2>

    <?php if ($error): ?>
        <p class="error"><?= htmlspecialchars($error) ?></p>
    <?php endif; ?>

    <form method="POST">

        <label>Title</label><br>
        <input type="text" name="title" required value="<?= htmlspecialchars($product['title']) ?>"><br><br>

        <label>Brand</label><br>
        <input type="text" name="brand" required value="<?= htmlspecialchars($product['brand'] ?? '') ?>"><br><br>

        <label>Description</label><br>
        <textarea name="description" rows="3" required><?= htmlspecialchars($product['description']) ?></textarea><br><br>

        <label>Price (R)</label><br>
        <input type="number" name="price" step="0.01" min="0" required value="<?= htmlspecialchars($product['price']) ?>"><br><br>

        <label>Category</label><br>
        <select name="category" required>
            <?php foreach (['Tops','Dresses','Pants','Jackets','Hoodies','Shoes','Bags','Sportswear','Suits','Accessories','Other'] as $cat): ?>
                <option value="<?= $cat ?>" <?= $product['category'] == $cat ? 'selected' : '' ?>>
                    <?= $cat ?>
                </option>
            <?php endforeach; ?>
        </select><br><br>

        <label>Size</label><br>
        <select name="size" required>
            <?php foreach (['XS','S','M','L','XL','XXL','7','8','9','One Size'] as $s): ?>
                <option value="<?= $s ?>" <?= $product['size'] == $s ? 'selected' : '' ?>>
                    <?= $s ?>
                </option>
            <?php endforeach; ?>
        </select><br><br>

        <label>Condition</label><br>
        <select name="condition_type" required>
            <?php foreach (['New','Like New','Good','Fair'] as $c): ?>
                <option value="<?= $c ?>" <?= $product['condition_type'] == $c ? 'selected' : '' ?>>
                    <?= $c ?>
                </option>
            <?php endforeach; ?>
        </select><br><br>

        <label>Status</label><br>
        <select name="status" required>
            <?php foreach (['active','sold','reserved'] as $st): ?>
                <option value="<?= $st ?>" <?= $product['status'] == $st ? 'selected' : '' ?>>
                    <?= ucfirst($st) ?>
                </option>
            <?php endforeach; ?>
        </select><br><br>

        <label>Image URL</label><br>
        <input type="text" name="image_url" required value="<?= htmlspecialchars($product['image_url'] ?? '') ?>"><br><br>

        <?php if (!empty($product['image_url'])): ?>
            <p>Current Image Preview:</p>
            <div class="product-image-container">
                <img src="<?= htmlspecialchars($product['image_url']) ?>" class="product-image">
            </div>
            <br>
        <?php endif; ?>

        <button type="submit">Save Changes</button>
    </form>
</div>

</body>
</html>