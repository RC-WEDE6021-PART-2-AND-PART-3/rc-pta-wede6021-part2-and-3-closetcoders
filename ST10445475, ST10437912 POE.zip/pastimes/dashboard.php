<?php 
session_start();
include "DBConn.php";

if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'buyer') {
    header("Location: login.php");
    exit();
}

// Add to cart
if (isset($_GET['add_cart'])) {
    $product_id = (int)$_GET['add_cart'];
    $buyer_id   = $_SESSION['user_id'];

    $check = $conn->query("SELECT * FROM tblCart WHERE buyer_id=$buyer_id AND product_id=$product_id");

    if ($check->num_rows == 0) {
        $conn->query("INSERT INTO tblCart (buyer_id, product_id) VALUES ($buyer_id, $product_id)");
    }

    header("Location: dashboard.php?added=1");
    exit();
}

/* Search and Filter */
$search = isset($_GET['search']) ? trim($_GET['search']) : "";
$category = isset($_GET['category']) ? trim($_GET['category']) : "";

$sql = "SELECT p.*, u.name as seller_name 
        FROM tblProducts p 
        JOIN tblUser u ON p.seller_id = u.user_id 
        WHERE p.status = 'active'";

if ($search != "") {
    $safe_search = $conn->real_escape_string($search);
    $sql .= " AND (
        p.title LIKE '%$safe_search%' 
        OR p.brand LIKE '%$safe_search%' 
        OR p.description LIKE '%$safe_search%'
    )";
}

if ($category != "") {
    $safe_category = $conn->real_escape_string($category);
    $sql .= " AND p.category = '$safe_category'";
}

$sql .= " ORDER BY p.date_listed DESC";

$products = $conn->query($sql);

$cart_count = $conn->query("SELECT COUNT(*) as cnt FROM tblCart WHERE buyer_id=" . $_SESSION['user_id']);
$cart_count = $cart_count->fetch_assoc()['cnt'];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Shop - Pastimes</title>
    <link rel="stylesheet" href="style.css?v=5">
</head>
<body>

<div class="topbar">
    <h1>Pastimes</h1>
    <div>
        Welcome, <?= htmlspecialchars($_SESSION['name']) ?> |
        <a href="cart.php">🛒 Cart (<?= $cart_count ?>)</a> |
        <a href="messages.php">Messages</a> |
        <a href="logout.php">Logout</a>
    </div>
</div>

<?php if (isset($_GET['added'])): ?>
    <p class="success-msg" style="text-align:center">Item added to cart!</p>
<?php endif; ?>

<h2>Browse Clothing</h2>

<form method="GET" style="padding: 0 20px 20px; display:flex; gap:10px; flex-wrap:wrap;">
    <input type="text" 
           name="search" 
           placeholder="Search by title, brand or description"
           value="<?= htmlspecialchars($search) ?>" 
           style="max-width:300px;">

    <select name="category" style="max-width:200px;">
        <option value="">All Categories</option>

        <?php foreach (['Tops','Dresses','Pants','Jackets','Hoodies','Shoes','Bags','Sportswear','Suits','Accessories','Other'] as $cat): ?>
            <option value="<?= $cat ?>" <?= $category == $cat ? 'selected' : '' ?>>
                <?= $cat ?>
            </option>
        <?php endforeach; ?>
    </select>

    <button type="submit">Search</button>

    <a href="dashboard.php">
        <button type="button" class="btn-outline">Clear</button>
    </a>
</form>

<div class="product-grid">

<?php if ($products && $products->num_rows > 0): ?>

    <?php while ($p = $products->fetch_assoc()): ?>
        <div class="product-card">

            <div class="product-image-container">
                <?php if (!empty($p['image_url'])): ?>
                    <img src="<?= htmlspecialchars($p['image_url']) ?>" 
                         alt="<?= htmlspecialchars($p['title']) ?>" 
                         class="product-image">
                <?php else: ?>
                    <div class="no-image">No Image</div>
                <?php endif; ?>
            </div>

            <div class="product-content">
                <div class="product-category">
                    <?= htmlspecialchars($p['category']) ?>
                </div>

                <h3><?= htmlspecialchars($p['title']) ?></h3>

                <?php if (!empty($p['brand'])): ?>
                    <p><strong>Brand:</strong> <?= htmlspecialchars($p['brand']) ?></p>
                <?php endif; ?>

                <p><?= htmlspecialchars($p['description']) ?></p>

                <p>
                    <strong>Size:</strong> <?= htmlspecialchars($p['size']) ?> |
                    <strong>Condition:</strong> <?= htmlspecialchars($p['condition_type']) ?>
                </p>

                <p>
                    <strong>Seller:</strong> <?= htmlspecialchars($p['seller_name']) ?>
                </p>

                <div class="product-footer">
                    <span class="price">R<?= number_format($p['price'], 2) ?></span>

                    <a href="?add_cart=<?= $p['product_id'] ?>">
                        <button>Add to Cart</button>
                    </a>

                    <a href="reviews.php?product_id=<?= $p['product_id'] ?>">
                        <button class="btn-outline">Reviews</button>
                    </a>
                </div>
            </div>

        </div>
    <?php endwhile; ?>

<?php else: ?>
    <p style="padding:20px;">No products found.</p>
<?php endif; ?>

</div>

</body>
</html>