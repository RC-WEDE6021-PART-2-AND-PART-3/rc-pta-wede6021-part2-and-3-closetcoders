<?php
session_start();
include "DBConn.php";

if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'seller') {
    header("Location: login.php");
    exit();
}

$seller_id = $_SESSION['user_id'];

if (isset($_POST['update_status'])) {
    $order_id = (int)$_POST['order_id'];
    $status = $_POST['status'];

    $conn->query("
        UPDATE tblOrders 
        SET status='$status' 
        WHERE order_id=$order_id AND seller_id=$seller_id
    ");

    $order = $conn->query("
        SELECT o.buyer_id, o.tracking_number, p.title 
        FROM tblOrders o
        JOIN tblProducts p ON o.product_id = p.product_id
        WHERE o.order_id=$order_id AND o.seller_id=$seller_id
    ")->fetch_assoc();

    if ($order) {
        $buyer_id = $order['buyer_id'];
        $subject = "Order Status Updated";
        $message = "Your order for '" . $order['title'] . "' is now marked as " . ucfirst($status) .
                   ". Tracking number: " . $order['tracking_number'];

        $subject = $conn->real_escape_string($subject);
        $message = $conn->real_escape_string($message);

        $conn->query("
            INSERT INTO tblMessages (sender_id, receiver_id, subject, message)
            VALUES ($seller_id, $buyer_id, '$subject', '$message')
        ");
    }

    header("Location: seller_orders.php?updated=1");
    exit();
}

$orders = $conn->query("
    SELECT o.*, p.title, p.image_url, b.name AS buyer_name, b.email AS buyer_email
    FROM tblOrders o
    JOIN tblProducts p ON o.product_id = p.product_id
    JOIN tblUser b ON o.buyer_id = b.user_id
    WHERE o.seller_id=$seller_id
    ORDER BY o.date_ordered DESC
");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Seller Orders - Pastimes</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

<div class="topbar">
    <h1>Seller Orders</h1>
    <div>
        <a href="seller_dashboard.php">My Listings</a> |
        <a href="messages.php">Messages</a> |
        <a href="logout.php">Logout</a>
    </div>
</div>

<div style="padding:20px;">
    <h2>Incoming Orders</h2>

    <?php if (isset($_GET['updated'])): ?>
        <p class="success-msg">Order status updated and buyer notified.</p>
    <?php endif; ?>

    <?php if (!$orders || $orders->num_rows == 0): ?>
        <p>No orders yet.</p>
    <?php else: ?>

    <table>
        <tr>
            <th>Order ID</th>
            <th>Image</th>
            <th>Product</th>
            <th>Buyer</th>
            <th>Email</th>
            <th>Total</th>
            <th>Delivery</th>
            <th>Tracking</th>
            <th>Status</th>
            <th>Update</th>
            <th>Shipping Label</th>
        </tr>

        <?php while ($o = $orders->fetch_assoc()): ?>
        <tr>
            <form method="POST">
                <td><?= $o['order_id'] ?></td>

                <td>
                    <?php if (!empty($o['image_url'])): ?>
                        <img src="<?= htmlspecialchars($o['image_url']) ?>" 
                             style="width:70px;height:70px;object-fit:cover;border-radius:6px;">
                    <?php else: ?>
                        No Image
                    <?php endif; ?>
                </td>

                <td><?= htmlspecialchars($o['title']) ?></td>
                <td><?= htmlspecialchars($o['buyer_name']) ?></td>
                <td><?= htmlspecialchars($o['buyer_email']) ?></td>
                <td>R<?= number_format($o['total'], 2) ?></td>
                <td><?= htmlspecialchars($o['delivery_method']) ?></td>
                <td><?= htmlspecialchars($o['tracking_number']) ?></td>

                <td>
                    <select name="status">
                        <?php foreach (['paid','shipped','completed','refunded'] as $status): ?>
                            <option value="<?= $status ?>" <?= $o['status'] == $status ? 'selected' : '' ?>>
                                <?= ucfirst($status) ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </td>

                <td>
                    <input type="hidden" name="order_id" value="<?= $o['order_id'] ?>">
                    <button type="submit" name="update_status">Update</button>
                </td>

                <td>
                    <a href="shipping_label.php?order_id=<?= $o['order_id'] ?>">
                        <button type="button">Generate Label</button>
                    </a>
                </td>
            </form>
        </tr>
        <?php endwhile; ?>
    </table>

    <?php endif; ?>
</div>

</body>
</html>