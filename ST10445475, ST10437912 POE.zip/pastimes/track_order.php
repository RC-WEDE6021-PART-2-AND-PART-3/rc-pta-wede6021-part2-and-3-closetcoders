<?php
session_start();
include "DBConn.php";

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id'];

$orders = $conn->query("
    SELECT o.*, p.title, p.image_url
    FROM tblOrders o
    JOIN tblProducts p ON o.product_id = p.product_id
    WHERE o.buyer_id = $user_id
    ORDER BY o.date_ordered DESC
");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Track Orders - Pastimes</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

<div class="topbar">
    <h1>Pastimes</h1>
    <div>
        <a href="dashboard.php">Continue Shopping</a> |
        <a href="cart.php">Cart</a> |
        <a href="logout.php">Logout</a>
    </div>
</div>

<div style="padding:20px;">

    <h2>My Orders</h2>

    <?php if (isset($_GET['success'])): ?>
        <p class="success-msg">
            Purchase completed successfully!
        </p>
    <?php endif; ?>

    <?php if ($orders->num_rows == 0): ?>

        <p>You have not placed any orders yet.</p>

    <?php else: ?>

        <table>
            <tr>
                <th>Order ID</th>
                <th>Image</th>
                <th>Product</th>
                <th>Amount</th>
                <th>Status</th>
                <th>Delivery Method</th>
                <th>Tracking Number</th>
                <th>Date Ordered</th>
            </tr>

            <?php while ($order = $orders->fetch_assoc()): ?>

            <tr>
                <td><?= $order['order_id'] ?></td>

                <td>
                    <?php if (!empty($order['image_url'])): ?>
                        <img src="<?= htmlspecialchars($order['image_url']) ?>"
                             style="width:80px;height:80px;object-fit:cover;border-radius:8px;">
                    <?php else: ?>
                        No Image
                    <?php endif; ?>
                </td>

                <td><?= htmlspecialchars($order['title']) ?></td>

                <td>
                    R<?= number_format($order['amount'], 2) ?>
                </td>

                <td>
                    <strong><?= ucfirst($order['status']) ?></strong>
                </td>

                <td>
                    <?= !empty($order['delivery_method'])
                        ? htmlspecialchars($order['delivery_method'])
                        : 'Not Assigned'; ?>
                </td>

                <td>
                    <?= !empty($order['tracking_number'])
                        ? htmlspecialchars($order['tracking_number'])
                        : 'Pending'; ?>
                </td>

                <td><?= $order['date_ordered'] ?></td>

            </tr>

            <?php endwhile; ?>

        </table>

    <?php endif; ?>

</div>

</body>
</html>