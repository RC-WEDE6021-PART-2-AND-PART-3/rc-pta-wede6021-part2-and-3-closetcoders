<?php
session_start();
include "DBConn.php";

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$product_id = (int)$_GET['product_id'];
$error = ""; $success = "";

$product = $conn->query("SELECT * FROM tblProducts WHERE product_id=$product_id")->fetch_assoc();
if (!$product) { die("Product not found."); }

if ($_SERVER["REQUEST_METHOD"] == "POST" && $_SESSION['role'] == 'buyer') {
    $rating  = (int)$_POST['rating'];
    $comment = $conn->real_escape_string(trim($_POST['comment']));
    $buyer_id = $_SESSION['user_id'];

    $existing = $conn->query("SELECT * FROM tblReviews WHERE product_id=$product_id AND buyer_id=$buyer_id");
    if ($existing->num_rows > 0) {
        $error = "You have already reviewed this item.";
    } else {
        $conn->query("INSERT INTO tblReviews (product_id, buyer_id, rating, comment) 
                      VALUES ($product_id, $buyer_id, $rating, '$comment')");
        $success = "Review submitted!";
    }
}

$reviews = $conn->query("SELECT r.*, u.name FROM tblReviews r 
                          JOIN tblUser u ON r.buyer_id = u.user_id 
                          WHERE r.product_id=$product_id ORDER BY r.date_reviewed DESC");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Reviews - Pastimes</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
<div class="topbar">
    <h1>Pastimes</h1>
    <div><a href="dashboard.php">← Back to Shop</a> | <a href="logout.php">Logout</a></div>
</div>

<div class="login-container" style="max-width:600px">
    <h2>Reviews for: <?= htmlspecialchars($product['title']) ?></h2>

    <?php if ($_SESSION['role'] == 'buyer'): ?>
        <h3>Leave a Review</h3>
        <?php if ($error) echo "<p class='error'>$error</p>"; ?>
        <?php if ($success) echo "<p class='success-msg'>$success</p>"; ?>
        <form method="POST">
            <label>Rating (1-5)</label><br>
            <select name="rating">
                <option value="5">⭐⭐⭐⭐⭐ 5</option>
                <option value="4">⭐⭐⭐⭐ 4</option>
                <option value="3">⭐⭐⭐ 3</option>
                <option value="2">⭐⭐ 2</option>
                <option value="1">⭐ 1</option>
            </select><br><br>
            <label>Comment</label><br>
            <textarea name="comment" rows="4" style="width:100%;padding:10px;border:1px solid #ccc;border-radius:4px" 
                      placeholder="Share your thoughts..." required></textarea><br><br>
            <button type="submit">Submit Review</button>
        </form>
        <hr>
    <?php endif; ?>

    <h3>All Reviews</h3>
    <?php if ($reviews->num_rows == 0): ?>
        <p>No reviews yet.</p>
    <?php else: ?>
        <?php while ($r = $reviews->fetch_assoc()): ?>
        <div class="review-card">
            <strong><?= htmlspecialchars($r['name']) ?></strong>
            <span style="color:gold"> <?= str_repeat('⭐', $r['rating']) ?></span>
            <p><?= htmlspecialchars($r['comment']) ?></p>
            <small><?= $r['date_reviewed'] ?></small>
        </div>
        <?php endwhile; ?>
    <?php endif; ?>
</div>
</body>
</html>