<?php
session_start();
include "DBConn.php";

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id'];

$messages = $conn->query("
    SELECT m.*, u.name AS sender_name
    FROM tblMessages m
    LEFT JOIN tblUser u ON m.sender_id = u.user_id
    WHERE m.receiver_id = $user_id
    ORDER BY m.date_sent DESC
");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>My Messages - Pastimes</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

<div class="topbar">
    <h1>Pastimes Messages</h1>
    <div>
        <a href="dashboard.php">Shop</a>
        <a href="cart.php">Cart</a>
        <a href="logout.php">Logout</a>
    </div>
</div>

<div class="login-container" style="max-width:850px;">
    <h2>My Messages</h2>

    <?php if ($messages->num_rows == 0): ?>
        <p>You have no messages yet.</p>
    <?php else: ?>
        <?php while ($msg = $messages->fetch_assoc()): ?>
            <div class="message-card">
                <h3><?= htmlspecialchars($msg['subject']) ?></h3>

                <p>
                    <strong>From:</strong>
                    <?= htmlspecialchars($msg['sender_name'] ?? 'Admin') ?>
                </p>

                <p><?= htmlspecialchars($msg['message']) ?></p>

                <small>
                    Sent on: <?= htmlspecialchars($msg['date_sent']) ?>
                </small>
            </div>
        <?php endwhile; ?>
    <?php endif; ?>
</div>

</body>
</html>