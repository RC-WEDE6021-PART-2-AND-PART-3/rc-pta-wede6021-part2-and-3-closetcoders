<?php
session_start();
include "DBConn.php";

if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'seller') {
    header("Location: login.php");
    exit();
}

$seller_id = $_SESSION['user_id'];
$order_id = (int)$_GET['order_id'];

$order = $conn->query("
    SELECT o.*, p.title, b.name AS buyer_name, b.email AS buyer_email
    FROM tblOrders o
    JOIN tblProducts p ON o.product_id = p.product_id
    JOIN tblUser b ON o.buyer_id = b.user_id
    WHERE o.order_id=$order_id AND o.seller_id=$seller_id
")->fetch_assoc();

if (!$order) {
    die("Order not found.");
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Shipping Label - Pastimes</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

<div class="login-container" style="max-width:600px;">
    <h1>PASTIMES SHIPPING LABEL</h1>

    <hr>

    <p><strong>Order ID:</strong> #<?= $order['order_id'] ?></p>
    <p><strong>Tracking Number:</strong> <?= htmlspecialchars($order['tracking_number']) ?></p>
    <p><strong>Product:</strong> <?= htmlspecialchars($order['title']) ?></p>

    <hr>

    <h3>Buyer Details</h3>
    <p><strong>Name:</strong> <?= htmlspecialchars($order['buyer_name']) ?></p>
    <p><strong>Email:</strong> <?= htmlspecialchars($order['buyer_email']) ?></p>
    <p><strong>Delivery Method:</strong> <?= htmlspecialchars($order['delivery_method']) ?></p>
    <p><strong>Delivery Address:</strong> <?= htmlspecialchars($order['delivery_address']) ?></p>

    <hr>

    <p><strong>Status:</strong> <?= ucfirst($order['status']) ?></p>

    <br>

    <button onclick="window.print()">Print Label</button>
    <a href="seller_orders.php"><button type="button" class="btn-outline">Back</button></a>
</div>

</body>
</html>