<?php
session_start();
include "DBConn.php";

if (!isset($_SESSION['admin_id'])) {
    header("Location: admin_login.php");
    exit();
}

/* APPROVE USER */
if (isset($_GET['approve'])) {
    $id = (int)$_GET['approve'];
    $conn->query("UPDATE tblUser SET status='approved' WHERE user_id=$id");
    header("Location: admin_dashboard.php");
    exit();
}

/* DELETE USER */
if (isset($_GET['delete_user'])) {
    $id = (int)$_GET['delete_user'];
    $conn->query("DELETE FROM tblUser WHERE user_id=$id");
    header("Location: admin_dashboard.php");
    exit();
}

/* DELETE PRODUCT */
if (isset($_GET['delete_product'])) {
    $id = (int)$_GET['delete_product'];
    $conn->query("DELETE FROM tblProducts WHERE product_id=$id");
    header("Location: admin_dashboard.php");
    exit();
}

/* ADD USER */
if (isset($_POST['add_user'])) {
    $name = $conn->real_escape_string($_POST['name']);
    $email = $conn->real_escape_string($_POST['email']);
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);
    $role = $_POST['role'];
    $status = $_POST['status'];

    $conn->query("INSERT INTO tblUser (name, email, password, role, status, join_date)
                  VALUES ('$name', '$email', '$password', '$role', '$status', NOW())");

    header("Location: admin_dashboard.php");
    exit();
}

/* UPDATE USER */
if (isset($_POST['update_user'])) {
    $id = (int)$_POST['user_id'];
    $name = $conn->real_escape_string($_POST['name']);
    $email = $conn->real_escape_string($_POST['email']);
    $role = $_POST['role'];
    $status = $_POST['status'];

    $conn->query("UPDATE tblUser 
                  SET name='$name', email='$email', role='$role', status='$status'
                  WHERE user_id=$id");

    header("Location: admin_dashboard.php");
    exit();
}

/* ADD PRODUCT */
if (isset($_POST['add_product'])) {
    $seller_id = (int)$_POST['seller_id'];
    $title = $conn->real_escape_string($_POST['title']);
    $brand = $conn->real_escape_string($_POST['brand']);
    $description = $conn->real_escape_string($_POST['description']);
    $price = (float)$_POST['price'];
    $category = $conn->real_escape_string($_POST['category']);
    $size = $conn->real_escape_string($_POST['size']);
    $condition_type = $conn->real_escape_string($_POST['condition_type']);
    $status = $_POST['status'];
    $image_url = $conn->real_escape_string($_POST['image_url']);

    $conn->query("INSERT INTO tblProducts 
        (seller_id, title, brand, description, price, category, size, condition_type, status, image_url)
        VALUES
        ($seller_id, '$title', '$brand', '$description', $price, '$category', '$size', '$condition_type', '$status', '$image_url')");

    header("Location: admin_dashboard.php");
    exit();
}

/* UPDATE PRODUCT */
if (isset($_POST['update_product'])) {
    $id = (int)$_POST['product_id'];
    $title = $conn->real_escape_string($_POST['title']);
    $brand = $conn->real_escape_string($_POST['brand']);
    $description = $conn->real_escape_string($_POST['description']);
    $price = (float)$_POST['price'];
    $category = $conn->real_escape_string($_POST['category']);
    $size = $conn->real_escape_string($_POST['size']);
    $condition_type = $conn->real_escape_string($_POST['condition_type']);
    $status = $_POST['status'];
    $image_url = $conn->real_escape_string($_POST['image_url']);

    $conn->query("UPDATE tblProducts 
                  SET title='$title',
                      brand='$brand',
                      description='$description',
                      price=$price,
                      category='$category',
                      size='$size',
                      condition_type='$condition_type',
                      status='$status',
                      image_url='$image_url'
                  WHERE product_id=$id");

    header("Location: admin_dashboard.php");
    exit();
}

/* SEND MESSAGE */
if (isset($_POST['send_message'])) {
    $receiver_id = (int)$_POST['receiver_id'];
    $subject = $conn->real_escape_string($_POST['subject']);
    $message = $conn->real_escape_string($_POST['message']);
    $admin_id = $_SESSION['admin_id'];

    $conn->query("INSERT INTO tblMessages (sender_id, receiver_id, subject, message)
                  VALUES ($admin_id, $receiver_id, '$subject', '$message')");

    header("Location: admin_dashboard.php?msg=sent");
    exit();
}

$users = $conn->query("SELECT * FROM tblUser WHERE role != 'admin' ORDER BY join_date DESC");
$sellers = $conn->query("SELECT user_id, name FROM tblUser WHERE role='seller'");
$products = $conn->query("SELECT p.*, u.name AS seller_name 
                          FROM tblProducts p 
                          JOIN tblUser u ON p.seller_id = u.user_id
                          ORDER BY p.product_id DESC");
$messages = $conn->query("SELECT m.*, u.name AS receiver_name, u.email AS receiver_email
                          FROM tblMessages m
                          LEFT JOIN tblUser u ON m.receiver_id = u.user_id
                          ORDER BY m.date_sent DESC");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Admin Dashboard - Pastimes</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

<div class="topbar">
    <h1>Pastimes — Admin Dashboard</h1>
    <div>
        Welcome, <?= htmlspecialchars($_SESSION['admin_name']) ?> |
        
        <a href="manage_orders.php">Manage Orders</a> |
        <a href="logout.php">Logout</a>
    </div>
</div>

<div style="padding:20px;">

<?php if (isset($_GET['msg'])): ?>
    <p class="success-msg">Message sent successfully.</p>
<?php endif; ?>

<h2>Add User</h2>
<form method="POST" class="login-container" style="max-width:700px; margin:20px 0;">
    <input type="text" name="name" placeholder="Full name" required><br><br>
    <input type="email" name="email" placeholder="Email" required><br><br>
    <input type="password" name="password" placeholder="Password" required><br><br>

    <select name="role" required>
        <option value="buyer">Buyer</option>
        <option value="seller">Seller</option>
    </select><br><br>

    <select name="status" required>
        <option value="approved">Approved</option>
        <option value="pending">Pending</option>
    </select><br><br>

    <button type="submit" name="add_user">Add User</button>
</form>

<h2>Manage Users</h2>
<table>
<tr>
    <th>ID</th><th>Name</th><th>Email</th><th>Role</th><th>Status</th><th>Actions</th>
</tr>

<?php while ($row = $users->fetch_assoc()): ?>
<tr>
<form method="POST">
    <td><?= $row['user_id'] ?></td>
    <td><input type="text" name="name" value="<?= htmlspecialchars($row['name']) ?>"></td>
    <td><input type="email" name="email" value="<?= htmlspecialchars($row['email']) ?>"></td>
    <td>
        <select name="role">
            <option value="buyer" <?= $row['role']=='buyer'?'selected':'' ?>>Buyer</option>
            <option value="seller" <?= $row['role']=='seller'?'selected':'' ?>>Seller</option>
        </select>
    </td>
    <td>
        <select name="status">
            <option value="approved" <?= $row['status']=='approved'?'selected':'' ?>>Approved</option>
            <option value="pending" <?= $row['status']=='pending'?'selected':'' ?>>Pending</option>
        </select>
    </td>
    <td>
        <input type="hidden" name="user_id" value="<?= $row['user_id'] ?>">
        <button type="submit" name="update_user">Update</button>

        <?php if ($row['status'] == 'pending'): ?>
            <a href="?approve=<?= $row['user_id'] ?>">Approve</a>
        <?php endif; ?>

        <a href="?delete_user=<?= $row['user_id'] ?>" onclick="return confirm('Delete this user?')">Delete</a>
    </td>
</form>
</tr>
<?php endwhile; ?>
</table>

<br><br>

<h2>Add Clothing/Product</h2>
<form method="POST" class="login-container" style="max-width:700px; margin:20px 0;">
    <select name="seller_id" required>
        <option value="">Select Seller</option>
        <?php while ($s = $sellers->fetch_assoc()): ?>
            <option value="<?= $s['user_id'] ?>"><?= htmlspecialchars($s['name']) ?></option>
        <?php endwhile; ?>
    </select><br><br>

    <input type="text" name="title" placeholder="Product title" required><br><br>
    <input type="text" name="brand" placeholder="Brand e.g. Nike, Gucci, Zara"><br><br>
    <textarea name="description" placeholder="Description" required></textarea><br><br>
    <input type="number" step="0.01" name="price" placeholder="Price" required><br><br>
    <input type="text" name="category" placeholder="Category e.g. Dresses, Shoes" required><br><br>
    <input type="text" name="size" placeholder="Size e.g. M, L, One Size" required><br><br>

    <select name="condition_type" required>
        <option value="Like New">Like New</option>
        <option value="Good">Good</option>
        <option value="Fair">Fair</option>
        <option value="New">New</option>
    </select><br><br>

    <select name="status" required>
        <option value="active">Active</option>
        <option value="sold">Sold</option>
        <option value="reserved">Reserved</option>
    </select><br><br>

    <input type="text" name="image_url" placeholder="images/example.jpg" required><br><br>

    <button type="submit" name="add_product">Add Product</button>
</form>

<h2>Manage Clothing/Products</h2>
<table>
<tr>
    <th>ID</th><th>Title</th><th>Brand</th><th>Price</th><th>Category</th><th>Size</th><th>Condition</th><th>Status</th><th>Image</th><th>Actions</th>
</tr>

<?php while ($p = $products->fetch_assoc()): ?>
<tr>
<form method="POST">
    <td><?= $p['product_id'] ?></td>
    <td><input type="text" name="title" value="<?= htmlspecialchars($p['title']) ?>"></td>
    <td><input type="text" name="brand" value="<?= htmlspecialchars($p['brand'] ?? '') ?>"></td>
    <td><input type="number" step="0.01" name="price" value="<?= $p['price'] ?>"></td>
    <td><input type="text" name="category" value="<?= htmlspecialchars($p['category']) ?>"></td>
    <td><input type="text" name="size" value="<?= htmlspecialchars($p['size']) ?>"></td>
    <td>
        <select name="condition_type">
            <option value="Like New" <?= $p['condition_type']=='Like New'?'selected':'' ?>>Like New</option>
            <option value="Good" <?= $p['condition_type']=='Good'?'selected':'' ?>>Good</option>
            <option value="Fair" <?= $p['condition_type']=='Fair'?'selected':'' ?>>Fair</option>
            <option value="New" <?= $p['condition_type']=='New'?'selected':'' ?>>New</option>
        </select>
    </td>
    <td>
        <select name="status">
            <option value="active" <?= $p['status']=='active'?'selected':'' ?>>Active</option>
            <option value="sold" <?= $p['status']=='sold'?'selected':'' ?>>Sold</option>
            <option value="reserved" <?= $p['status']=='reserved'?'selected':'' ?>>Reserved</option>
        </select>
    </td>
    <td><input type="text" name="image_url" value="<?= htmlspecialchars($p['image_url']) ?>"></td>
    <td>
        <input type="hidden" name="product_id" value="<?= $p['product_id'] ?>">
        <textarea name="description" style="display:none;"><?= htmlspecialchars($p['description']) ?></textarea>
        <button type="submit" name="update_product">Update</button>
        <a href="?delete_product=<?= $p['product_id'] ?>" onclick="return confirm('Delete this product?')">Delete</a>
    </td>
</form>
</tr>
<?php endwhile; ?>
</table>

<br><br>

<h2>Send Message to Buyer or Seller</h2>
<form method="POST" class="login-container" style="max-width:700px; margin:20px 0;">
    <select name="receiver_id" required>
        <option value="">Choose buyer or seller</option>
        <?php
        $user_list = $conn->query("SELECT user_id, name, email, role FROM tblUser WHERE role != 'admin'");
        while ($u = $user_list->fetch_assoc()):
        ?>
            <option value="<?= $u['user_id'] ?>">
                <?= htmlspecialchars($u['name']) ?> - <?= htmlspecialchars($u['role']) ?>
            </option>
        <?php endwhile; ?>
    </select><br><br>

    <input type="text" name="subject" placeholder="Subject" required><br><br>
    <textarea name="message" placeholder="Type message..." required></textarea><br><br>
    <button type="submit" name="send_message">Send Message</button>
</form>

<h2>Sent Messages</h2>
<table>
<tr>
    <th>To</th><th>Email</th><th>Subject</th><th>Message</th><th>Date</th>
</tr>

<?php while ($m = $messages->fetch_assoc()): ?>
<tr>
    <td><?= htmlspecialchars($m['receiver_name'] ?? 'Unknown') ?></td>
    <td><?= htmlspecialchars($m['receiver_email'] ?? 'N/A') ?></td>
    <td><?= htmlspecialchars($m['subject']) ?></td>
    <td><?= htmlspecialchars($m['message']) ?></td>
    <td><?= htmlspecialchars($m['date_sent']) ?></td>
</tr>
<?php endwhile; ?>
</table>

</div>
</body>
</html>