<?php
session_start();
include "DBConn.php";

$email_input = "";
$error = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email_input    = trim($_POST['email']);
    $password_input = trim($_POST['password']);

    $stmt = $conn->prepare("SELECT * FROM tblUser WHERE email = ?");
    $stmt->bind_param("s", $email_input);
    $stmt->execute();
    $result = $stmt->get_result();
    $user   = $result->fetch_assoc();

    if (!$user) {
        $error = "not_found";
    } elseif (!password_verify($password_input, $user['password'])) {
        $error = "wrong_password";
    } else {
        $_SESSION['user_id'] = $user['user_id'];
        $_SESSION['name']    = $user['name'];
        $_SESSION['role']    = $user['role'];

        if ($user['role'] == 'admin') {
            $_SESSION['admin_id']   = $user['user_id'];
            $_SESSION['admin_name'] = $user['name'];
            header("Location: admin_dashboard.php");
        } elseif ($user['role'] == 'seller') {
            header("Location: seller_dashboard.php");
        } else {
            header("Location: dashboard.php");
        }
        exit();
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Login - Pastimes</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
<div class="login-container">
    <h1>Pastimes</h1>
    <h2>Login</h2>

    <?php if ($error == "wrong_password"): ?>
        <p class="error">Incorrect password. Please try again.</p>
    <?php elseif ($error == "not_found"): ?>
        <p class="error">No account found. <a href="register.php">Register here</a></p>
    <?php endif; ?>

    <form method="POST">
        <label>Email Address</label><br>
        <input type="email" name="email"
               value="<?= htmlspecialchars($email_input) ?>"
               required placeholder="Enter your email"><br><br>

        <label>Password</label><br>
        <input type="password" name="password"
               required placeholder="Enter your password"><br><br>

        <button type="submit">Login</button>
        <a href="admin_login.php"><button type="button">Admin Login</button></a>
    </form>

    <p>No account? <a href="register.php">Register</a></p>
</div>
</body>
</html>