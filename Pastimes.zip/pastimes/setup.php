<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
include "DBConn.php";

$conn->query("DROP TABLE IF EXISTS tblUser");

$conn->query("
CREATE TABLE tblUser (
    user_id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100),
    email VARCHAR(100) UNIQUE,
    password VARCHAR(255),
    role ENUM('buyer','seller','admin') DEFAULT 'buyer',
    status ENUM('pending','approved') DEFAULT 'pending',
    join_date DATETIME DEFAULT CURRENT_TIMESTAMP,
    wallet_balance DECIMAL(10,2) DEFAULT 0
)");

echo "Table created.<br>";

// Insert a default admin
$adminPassword = password_hash("admin123", PASSWORD_DEFAULT);
$conn->query("INSERT INTO tblUser (name, email, password, role, status) 
              VALUES ('Admin', 'admin@pastimes.co.za', '$adminPassword', 'admin', 'approved')");

echo "Admin created. Email: admin@pastimes.co.za | Password: admin123<br>";

// Load userData.txt if it exists
if (file_exists("userData.txt")) {
    $file = fopen("userData.txt", "r");
    if ($file) {
        while (($line = fgets($file)) !== false) {
            $line = trim($line);
            if (empty($line)) continue;
            $parts = explode("\t", $line);
            if (count($parts) < 4) continue;
            $name     = $conn->real_escape_string($parts[1]);
            $email    = $conn->real_escape_string($parts[2]);
            $password = password_hash(trim($parts[3]), PASSWORD_DEFAULT);
            $conn->query("INSERT IGNORE INTO tblUser (name, email, password, status) 
                          VALUES ('$name', '$email', '$password', 'approved')");
        }
        fclose($file);
        echo "userData.txt loaded.<br>";
    }
}

echo "<br><strong>Setup complete. <a href='login.php'>Go to Login</a></strong>";
?>