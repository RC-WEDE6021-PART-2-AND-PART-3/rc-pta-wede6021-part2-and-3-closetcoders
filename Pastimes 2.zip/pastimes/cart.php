<?php
session_start();
include "DBConn.php";

if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'buyer') {
    header("Location: login.php");
    exit();
}

$buyer_id = $_SESSION['user_id'];

// Remove item
if (isset($_GET['remove'])) {
    $cart_id = (int)$_GET['remove'];
    $conn->query("DELETE FROM tblCart WHERE cart_id=$cart_id AND buyer_id=$buyer_id");
    header("Location: cart.php");
    exit();
}

// Purchase all
if (isset($_POST['purchase'])) {
    $cart_items = $conn->query("SELECT c.cart_id, p.product_id, p.price 
                                 FROM tblCart c JOIN tblProducts p ON c.product_id = p.product_id 
                                 WHERE c.buyer_id=$buyer_id AND p.status='active'");
    while ($item = $cart_items->fetch_assoc()) {
        $conn->query("INSERT INTO tblOrders (buyer_id, product_id, amount) 
                      VALUES ($buyer_id, {$item['product_id']}, {$item['price']})");
        $conn->query("UPDATE tblProducts SET status='sold' WHERE product_id={$item['product_id']}");
        $conn->query("DELETE FROM tblCart WHERE cart_id={$item['cart_id']}");
    }
    header("Location: cart.php?purchased=1");
    exit();
}

$cart_items = $conn->query("SELECT c.cart_id, p.*, u.name as seller_name 
                              FROM tblCart c 
                              JOIN tblProducts p ON c.product_id = p.product_id 
                              JOIN tblUser u ON p.seller_id = u.user_id
                              WHERE c.buyer_id=$buyer_id AND p.status='active'");

$total_result = $conn->query("SELECT SUM(p.price) as total FROM tblCart c 
                               JOIN tblProducts p ON c.product_id = p.product_id 
                               WHERE c.buyer_id=$buyer_id AND p.status='active'");
$total = $total_result->fetch_assoc()['total'] ?? 0;
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Cart - Pastimes</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
<div class="topbar">
    <h1>Pastimes</h1>
    <div>
        Welcome, <?= htmlspecialchars($_SESSION['name']) ?> |
        <a href="dashboard.php">← Back to Shop</a> |
        <a href="logout.php">Logout</a>
    </div>
</div>

<div class="login-container" style="max-width:700px">
    <h2>Your Cart</h2>

    <?php if (isset($_GET['purchased'])): ?>
        <p class="success-msg">Purchase successful! Thank you.</p>
    <?php endif; ?>

    <?php if ($cart_items->num_rows == 0 && !isset($_GET['purchased'])): ?>
        <p>Your cart is empty. <a href="dashboard.php">Browse items</a></p>
    <?php else: ?>
        <table>
            <tr><th>Item</th><th>Size</th><th>Condition</th><th>Seller</th><th>Price</th><th>Remove</th></tr>
            <?php while ($item = $cart_items->fetch_assoc()): ?>
            <tr>
                <td><?= htmlspecialchars($item['title']) ?></td>
                <td><?= $item['size'] ?></td>
                <td><?= $item['condition_type'] ?></td>
                <td><?= htmlspecialchars($item['seller_name']) ?></td>
                <td>R<?= number_format($item['price'], 2) ?></td>
                <td><a href="?remove=<?= $item['cart_id'] ?>">Remove</a></td>
            </tr>
            <?php endwhile; ?>
        </table>

        <br>
        <p><strong>Total: R<?= number_format($total, 2) ?></strong></p>

        <form method="POST">
            <button type="submit" name="purchase">Purchase All</button>
        </form>
    <?php endif; ?>
</div>
</body>
</html>