<?php
session_start();
include "DBConn.php";

if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'seller') {
    header("Location: login.php");
    exit();
}

$product_id = (int)$_GET['product_id'];
$seller_id  = $_SESSION['user_id'];
$error = "";

$product = $conn->query("SELECT * FROM tblProducts WHERE product_id=$product_id AND seller_id=$seller_id")->fetch_assoc();
if (!$product) { die("Product not found."); }

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $title      = trim($_POST['title']);
    $description= trim($_POST['description']);
    $price      = (float)$_POST['price'];
    $category   = trim($_POST['category']);
    $size       = trim($_POST['size']);
    $condition  = $_POST['condition_type'];

    $stmt = $conn->prepare("UPDATE tblProducts SET title=?, description=?, price=?, category=?, size=?, condition_type=? 
                            WHERE product_id=? AND seller_id=?");
    $stmt->bind_param("ssdsssi i", $title, $description, $price, $category, $size, $condition, $product_id, $seller_id);

    if ($stmt->execute()) {
        header("Location: seller_dashboard.php?saved=1");
        exit();
    } else {
        $error = "Something went wrong.";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Edit Item - Pastimes</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
<div class="topbar">
    <h1>Pastimes</h1>
    <div><a href="seller_dashboard.php">← Back to My Listings</a> | <a href="logout.php">Logout</a></div>
</div>

<div class="login-container">
    <h2>Edit Item</h2>
    <?php if ($error) echo "<p class='error'>$error</p>"; ?>

    <form method="POST">
        <label>Title</label><br>
        <input type="text" name="title" required value="<?= htmlspecialchars($product['title']) ?>"><br><br>

        <label>Description</label><br>
        <textarea name="description" rows="3" required
                  style="width:100%;padding:10px;border:1px solid #ccc;border-radius:4px"
                  ><?= htmlspecialchars($product['description']) ?></textarea><br><br>

        <label>Price (R)</label><br>
        <input type="number" name="price" step="0.01" min="0" required value="<?= $product['price'] ?>"><br><br>

        <label>Category</label><br>
        <select name="category">
            <?php foreach (['Tops','Dresses','Pants','Jackets','Hoodies','Shoes','Accessories','Other'] as $cat): ?>
                <option <?= $product['category'] == $cat ? 'selected' : '' ?>><?= $cat ?></option>
            <?php endforeach; ?>
        </select><br><br>

        <label>Size</label><br>
        <select name="size">
            <?php foreach (['XS','S','M','L','XL','XXL','One Size'] as $s): ?>
                <option <?= $product['size'] == $s ? 'selected' : '' ?>><?= $s ?></option>
            <?php endforeach; ?>
        </select><br><br>

        <label>Condition</label><br>
        <select name="condition_type">
            <?php foreach (['Like New','Good','Fair'] as $c): ?>
                <option <?= $product['condition_type'] == $c ? 'selected' : '' ?>><?= $c ?></option>
            <?php endforeach; ?>
        </select><br><br>

        <button type="submit">Save Changes</button>
    </form>
</div>
</body>
</html>