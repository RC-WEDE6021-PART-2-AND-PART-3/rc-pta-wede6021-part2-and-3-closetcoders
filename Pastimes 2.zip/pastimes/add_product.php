<?php
session_start();
include "DBConn.php";

if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'seller') {
    header("Location: login.php");
    exit();
}

$error = ""; $success = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $seller_id  = $_SESSION['user_id'];
    $title      = trim($_POST['title']);
    $description= trim($_POST['description']);
    $price      = (float)$_POST['price'];
    $category   = trim($_POST['category']);
    $size       = trim($_POST['size']);
    $condition  = $_POST['condition_type'];

    $stmt = $conn->prepare("INSERT INTO tblProducts (seller_id, title, description, price, category, size, condition_type) 
                            VALUES (?, ?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("issdss s", $seller_id, $title, $description, $price, $category, $size, $condition);

    if ($stmt->execute()) {
        header("Location: seller_dashboard.php?saved=1");
        exit();
    } else {
        $error = "Something went wrong. Please try again.";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Add Item - Pastimes</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
<div class="topbar">
    <h1>Pastimes</h1>
    <div><a href="seller_dashboard.php">← Back to My Listings</a> | <a href="logout.php">Logout</a></div>
</div>

<div class="login-container">
    <h2>Add New Item</h2>
    <?php if ($error) echo "<p class='error'>$error</p>"; ?>

    <form method="POST">
        <label>Title</label><br>
        <input type="text" name="title" required placeholder="e.g. Vintage Denim Jacket"><br><br>

        <label>Description</label><br>
        <textarea name="description" rows="3" required
                  style="width:100%;padding:10px;border:1px solid #ccc;border-radius:4px"
                  placeholder="Describe the item..."></textarea><br><br>

        <label>Price (R)</label><br>
        <input type="number" name="price" step="0.01" min="0" required placeholder="e.g. 250.00"><br><br>

        <label>Category</label><br>
        <select name="category">
            <option>Tops</option>
            <option>Dresses</option>
            <option>Pants</option>
            <option>Jackets</option>
            <option>Hoodies</option>
            <option>Shoes</option>
            <option>Accessories</option>
            <option>Other</option>
        </select><br><br>

        <label>Size</label><br>
        <select name="size">
            <option>XS</option>
            <option>S</option>
            <option>M</option>
            <option>L</option>
            <option>XL</option>
            <option>XXL</option>
            <option>One Size</option>
        </select><br><br>

        <label>Condition</label><br>
        <select name="condition_type">
            <option>Like New</option>
            <option>Good</option>
            <option>Fair</option>
        </select><br><br>

        <button type="submit">Add Item</button>
    </form>
</div>
</body>
</html>