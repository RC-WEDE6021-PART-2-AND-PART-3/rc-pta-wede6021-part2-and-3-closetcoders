<?php
session_start();
include "DBConn.php";

if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'buyer') {
    header("Location: login.php");
    exit();
}

// Add to cart
if (isset($_GET['add_cart'])) {
    $product_id = (int)$_GET['add_cart'];
    $buyer_id   = $_SESSION['user_id'];
    $check = $conn->query("SELECT * FROM tblCart WHERE buyer_id=$buyer_id AND product_id=$product_id");
    if ($check->num_rows == 0) {
        $conn->query("INSERT INTO tblCart (buyer_id, product_id) VALUES ($buyer_id, $product_id)");
    }
    header("Location: dashboard.php?added=1");
    exit();
}

$products = $conn->query("SELECT p.*, u.name as seller_name FROM tblProducts p 
                           JOIN tblUser u ON p.seller_id = u.user_id 
                           WHERE p.status = 'active' ORDER BY p.date_listed DESC");

$cart_count = $conn->query("SELECT COUNT(*) as cnt FROM tblCart WHERE buyer_id=" . $_SESSION['user_id']);
$cart_count = $cart_count->fetch_assoc()['cnt'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Shop - Pastimes</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
<div class="topbar">
    <h1>Pastimes</h1>
    <div>
        Welcome, <?= htmlspecialchars($_SESSION['name']) ?> |
        <a href="cart.php">🛒 Cart (<?= $cart_count ?>)</a> |
        <a href="logout.php">Logout</a>
    </div>
</div>

<?php if (isset($_GET['added'])): ?>
    <p class="success-msg" style="text-align:center">Item added to cart!</p>
<?php endif; ?>

<h2 style="padding: 0 20px;">Browse Clothing</h2>

<div class="product-grid">
<?php while ($p = $products->fetch_assoc()): ?>
    <div class="product-card">
        <div class="product-category"><?= htmlspecialchars($p['category']) ?></div>
        <h3><?= htmlspecialchars($p['title']) ?></h3>
        <p><?= htmlspecialchars($p['description']) ?></p>
        <p><strong>Size:</strong> <?= $p['size'] ?> | <strong>Condition:</strong> <?= $p['condition_type'] ?></p>
        <p><strong>Seller:</strong> <?= htmlspecialchars($p['seller_name']) ?></p>
        <div class="product-footer">
            <span class="price">R<?= number_format($p['price'], 2) ?></span>
            <a href="?add_cart=<?= $p['product_id'] ?>"><button>Add to Cart</button></a>
            <a href="reviews.php?product_id=<?= $p['product_id'] ?>"><button class="btn-outline">Reviews</button></a>
        </div>
    </div>
<?php endwhile; ?>
</div>
</body>
</html>